def nearest_larger(arr, idx)
end
