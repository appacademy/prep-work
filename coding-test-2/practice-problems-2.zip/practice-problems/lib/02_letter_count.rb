def letter_count(str)
end
